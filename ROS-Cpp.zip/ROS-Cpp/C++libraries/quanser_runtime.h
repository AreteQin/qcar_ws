#if !defined(_quanser_runtime_h)
#define _quanser_runtime_h

#include "quanser_extern.h"

#endif
